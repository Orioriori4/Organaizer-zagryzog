@echo off
REM Скрипт для быстрого запуска органайзера на Windows

cd /d "%~dp0"
python organizer.py %*