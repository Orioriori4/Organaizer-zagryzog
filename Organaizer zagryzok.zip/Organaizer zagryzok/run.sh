#!/bin/bash
# Скрипт для быстрого запуска органайзера

cd "$(dirname "$0")"
python3 organizer.py "$@"