1. Создайте файлы
Создайте все вышеуказанные файлы в одной папке.

2. Первый запуск
bash
# Простой запуск
python organizer.py

# Тестовый запуск (ничего не перемещает)
python organizer.py --dry-run

# Запуск с подробным выводом
python organizer.py --verbose
3. Режим наблюдения
bash
# Проверять каждые 30 минут
python organizer.py --watch 30

# Проверять каждые 5 минут с подробным выводом
python organizer.py --watch 5 --verbose
4. Использование своего конфига
bash
python organizer.py --config my_settings.json
5. Указать другую папку
bash
python organizer.py --path "C:\Users\YourName\Desktop\Downloads"
 Установка как пакета (опционально)
Создайте файл setup.py для установки через pip:

python
from setuptools import setup, find_packages

setup(
    name="download-organizer",
    version="1.0.0",
    author="Your Name",
    description="Automatic download folder organizer",
    packages=find_packages(),
    py_modules=["organizer", "logger"],
    install_requires=[],
    entry_points={
        "console_scripts": [
            "organize-downloads=organizer:main",
        ],
    },
    python_requires=">=3.7",
)
Затем установите:

bash
pip install -e .
После этого можно запускать просто командой:

bash
organize-downloads