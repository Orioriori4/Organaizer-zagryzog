"""
Модуль для настройки логирования
"""

import logging
import sys
from pathlib import Path


def setup_logger(name: str, log_file: str = "organizer.log", level: int = logging.INFO) -> logging.Logger:
    """
    Настройка логгера с выводом в консоль и файл

    Args:
        name: имя логгера
        log_file: путь к файлу лога
        level: уровень логирования

    Returns:
        настроенный логгер
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)

    # Очищаем существующие обработчики, чтобы не дублировать
    if logger.handlers:
        logger.handlers.clear()

    # Формат сообщений
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    # Обработчик для консоли
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # Обработчик для файла
    try:
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    except Exception as e:
        logger.warning(f"Could not create log file: {e}")

    return logger


def log_action(logger: logging.Logger, action: str, source: Path, destination: Path) -> None:
    """
    Логирование действия с файлом

    Args:
        logger: логгер
        action: действие (MOVED, COPIED, DELETED, etc.)
        source: исходный путь
        destination: путь назначения
    """
    logger.info(f"{action}: '{source.name}' -> '{destination.parent.name}/{destination.name}'")