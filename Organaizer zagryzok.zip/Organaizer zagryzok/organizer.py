#!/usr/bin/env python3
"""
Download Organizer - автоматическая сортировка файлов в папке загрузок
"""

import os
import shutil
import json
import argparse
import time
import sys
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple, Optional

# Импортируем модуль логирования (создадим его позже)
try:
    from logger import setup_logger, log_action
except ImportError:
    # Упрощенное логирование, если logger.py отсутствует
    import logging

    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


    def setup_logger(name):
        return logging.getLogger(name)


    def log_action(logger, action, src, dst):
        logger.info(f"{action}: {src} -> {dst}")


class DownloadOrganizer:
    """Основной класс для организации загрузок"""

    def __init__(self, config_path: str = "config.json"):
        """
        Инициализация органайзера

        Args:
            config_path: путь к файлу конфигурации
        """
        self.config = self.load_config(config_path)
        self.logger = setup_logger("DownloadOrganizer")
        self.stats = {
            "moved": 0,
            "skipped": 0,
            "errors": 0,
            "categories": {}
        }

    def load_config(self, config_path: str) -> Dict:
        """
        Загрузка конфигурации из JSON файла

        Args:
            config_path: путь к файлу конфигурации

        Returns:
            словарь с настройками
        """
        default_config = {
            "downloads_folder": "~/Downloads",
            "categories": {
                "Images": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".webp", ".ico"],
                "Documents": [".pdf", ".docx", ".doc", ".txt", ".xlsx", ".xls", ".pptx", ".ppt", ".md", ".rtf", ".odt"],
                "Audio": [".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a", ".wma"],
                "Video": [".mp4", ".mkv", ".mov", ".avi", ".wmv", ".flv", ".webm", ".m4v"],
                "Archives": [".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".xz", ".tgz"],
                "Executables": [".exe", ".msi", ".dmg", ".appimage", ".sh", ".bat", ".cmd", ".ps1"],
                "Code": [".py", ".js", ".html", ".css", ".cpp", ".c", ".h", ".java", ".php", ".rb", ".go", ".rs",
                         ".json", ".xml", ".yaml", ".yml"],
                "Torrents": [".torrent"],
                "ISO": [".iso", ".img"],
                "Fonts": [".ttf", ".otf", ".woff", ".woff2"]
            },
            "ignore_extensions": [".tmp", ".crdownload", ".part", ".download", ".opdownload"],
            "ignore_folders": ["Images", "Documents", "Audio", "Video", "Archives", "Executables", "Code", "Torrents",
                               "ISO", "Fonts"],
            "case_sensitive": False,
            "create_category_folders": True,
            "dry_run": False,
            "log_file": "organizer.log"
        }

        # Создаем конфиг по умолчанию, если файл не существует
        if not os.path.exists(config_path):
            self.logger.warning(f"Config file {config_path} not found. Creating default config.")
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(default_config, f, indent=4, ensure_ascii=False)
            return default_config

        # Загружаем существующий конфиг
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                user_config = json.load(f)
                # Объединяем с дефолтным (на случай отсутствия некоторых ключей)
                for key, value in default_config.items():
                    if key not in user_config:
                        user_config[key] = value
                return user_config
        except Exception as e:
            self.logger.error(f"Error loading config: {e}. Using default config.")
            return default_config

    def get_downloads_path(self) -> Path:
        """
        Получение пути к папке загрузок

        Returns:
            Path объект с путем к загрузкам
        """
        downloads_path = self.config["downloads_folder"]

        # Обрабатываем тильду (~) для домашней директории
        if downloads_path.startswith("~"):
            downloads_path = os.path.expanduser(downloads_path)

        # Обрабатываем переменные окружения (например %USERPROFILE% на Windows)
        downloads_path = os.path.expandvars(downloads_path)

        path = Path(downloads_path).resolve()

        if not path.exists():
            self.logger.error(f"Downloads folder not found: {path}")
            raise FileNotFoundError(f"Downloads folder not found: {path}")

        return path

    def get_category_for_file(self, filename: str) -> Optional[str]:
        """
        Определение категории файла по его расширению

        Args:
            filename: имя файла

        Returns:
            название категории или None если категория не найдена
        """
        file_ext = Path(filename).suffix.lower()

        # Пропускаем игнорируемые расширения
        if file_ext in self.config["ignore_extensions"]:
            return None

        # Поиск категории
        for category, extensions in self.config["categories"].items():
            # Приводим к нижнему регистру для сравнения (если не case_sensitive)
            if not self.config["case_sensitive"]:
                extensions = [ext.lower() for ext in extensions]
                file_ext = file_ext.lower()

            if file_ext in extensions:
                return category

        # Если категория не найдена - помещаем в "Other"
        return "Other"

    def organize_file(self, file_path: Path, downloads_path: Path) -> bool:
        """
        Организация одного файла (перемещение в соответствующую папку)

        Args:
            file_path: путь к файлу
            downloads_path: путь к папке загрузок

        Returns:
            True если файл был перемещен, False в противном случае
        """
        # Пропускаем папки
        if file_path.is_dir():
            self.logger.debug(f"Skipping directory: {file_path.name}")
            return False

        # Пропускаем скрытые файлы (начинающиеся с точки)
        if file_path.name.startswith('.'):
            self.logger.debug(f"Skipping hidden file: {file_path.name}")
            self.stats["skipped"] += 1
            return False

        # Определяем категорию
        category = self.get_category_for_file(file_path.name)

        if category is None:
            self.logger.debug(f"Skipping ignored file: {file_path.name}")
            self.stats["skipped"] += 1
            return False

        # Создаем путь к папке назначения
        dest_folder = downloads_path / category

        # Создаем папку, если нужно
        if self.config["create_category_folders"] and not dest_folder.exists():
            if not self.config["dry_run"]:
                dest_folder.mkdir(parents=True, exist_ok=True)
                self.logger.info(f"Created folder: {dest_folder}")
            else:
                self.logger.info(f"[DRY RUN] Would create folder: {dest_folder}")

        # Формируем путь назначения
        dest_path = dest_folder / file_path.name

        # Обработка конфликта имен (если файл уже существует)
        if dest_path.exists():
            base_name = file_path.stem
            extension = file_path.suffix
            counter = 1
            while dest_path.exists():
                new_name = f"{base_name}_{counter}{extension}"
                dest_path = dest_folder / new_name
                counter += 1
            self.logger.warning(f"File {file_path.name} already exists. Renaming to {dest_path.name}")

        # Перемещаем файл
        try:
            if not self.config["dry_run"]:
                shutil.move(str(file_path), str(dest_path))
                log_action(self.logger, "MOVED", file_path, dest_path)
            else:
                log_action(self.logger, "WOULD MOVE", file_path, dest_path)

            # Обновляем статистику
            self.stats["moved"] += 1
            self.stats["categories"][category] = self.stats["categories"].get(category, 0) + 1

            return True

        except Exception as e:
            self.logger.error(f"Error moving {file_path.name}: {e}")
            self.stats["errors"] += 1
            return False

    def organize_downloads(self) -> Dict:
        """
        Основная функция организации всех файлов в папке загрузок

        Returns:
            словарь со статистикой
        """
        try:
            downloads_path = self.get_downloads_path()
        except FileNotFoundError as e:
            self.logger.error(str(e))
            return self.stats

        self.logger.info(f"Organizing downloads in: {downloads_path}")

        # Получаем список файлов в папке
        files = [f for f in downloads_path.iterdir() if f.is_file()]

        # Пропускаем файлы в папках, которые нужно игнорировать
        ignore_folders = self.config.get("ignore_folders", [])
        files_to_organize = []

        for file_path in files:
            # Проверяем, не находится ли файл в игнорируемой папке
            parent_folder = file_path.parent.name
            if parent_folder in ignore_folders:
                self.logger.debug(f"Skipping file in ignored folder: {file_path}")
                self.stats["skipped"] += 1
                continue
            files_to_organize.append(file_path)

        if not files_to_organize:
            self.logger.info("No files to organize")
            return self.stats

        self.logger.info(f"Found {len(files_to_organize)} files to organize")

        # Организуем каждый файл
        for file_path in files_to_organize:
            self.organize_file(file_path, downloads_path)

        # Выводим статистику
        self.print_stats()

        return self.stats

    def print_stats(self) -> None:
        """Вывод статистики работы"""
        self.logger.info("=" * 50)
        self.logger.info("ORGANIZATION COMPLETE")
        self.logger.info(f"Files moved: {self.stats['moved']}")
        self.logger.info(f"Files skipped: {self.stats['skipped']}")
        self.logger.info(f"Errors: {self.stats['errors']}")

        if self.stats['categories']:
            self.logger.info("\nFiles by category:")
            for category, count in sorted(self.stats['categories'].items()):
                self.logger.info(f"  {category}: {count} file(s)")

        if self.config["dry_run"]:
            self.logger.info("\n*** DRY RUN MODE - No files were actually moved ***")

        self.logger.info("=" * 50)

    def watch_mode(self, interval_minutes: int = 30) -> None:
        """
        Режим наблюдения - периодическая проверка папки загрузок

        Args:
            interval_minutes: интервал между проверками в минутах
        """
        self.logger.info(f"Starting watch mode. Checking every {interval_minutes} minutes")

        try:
            while True:
                self.organize_downloads()
                self.logger.info(f"Waiting {interval_minutes} minutes until next check...")
                time.sleep(interval_minutes * 60)
        except KeyboardInterrupt:
            self.logger.info("Watch mode stopped by user")


def main():
    """Основная функция для запуска из командной строки"""
    parser = argparse.ArgumentParser(
        description="Download Organizer - автоматическая сортировка файлов в папке загрузок",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Примеры использования:
  %(prog)s                          # Запуск с конфигом по умолчанию
  %(prog)s --config my_config.json  # Использовать свой конфиг
  %(prog)s --watch 15               # Режим наблюдения (проверка каждые 15 минут)
  %(prog)s --dry-run                # Тестовый запуск без перемещения файлов
  %(prog)s --path ~/Загрузки        # Указать другую папку
        """
    )

    parser.add_argument(
        "--config", "-c",
        type=str,
        default="config.json",
        help="Путь к файлу конфигурации (по умолчанию: config.json)"
    )

    parser.add_argument(
        "--watch", "-w",
        type=int,
        metavar="MINUTES",
        help="Режим наблюдения с указанным интервалом в минутах"
    )

    parser.add_argument(
        "--dry-run", "-d",
        action="store_true",
        help="Тестовый запуск (не перемещает файлы)"
    )

    parser.add_argument(
        "--path", "-p",
        type=str,
        help="Переопределить путь к папке загрузок"
    )

    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Подробный вывод (debug режим)"
    )

    args = parser.parse_args()

    # Создаем органайзер
    organizer = DownloadOrganizer(args.config)

    # Переопределяем путь к загрузкам если указан
    if args.path:
        organizer.config["downloads_folder"] = args.path

    # Включаем dry-run режим если указан
    if args.dry_run:
        organizer.config["dry_run"] = True
        organizer.logger.info("DRY RUN MODE ENABLED - No files will be moved")

    # Устанавливаем уровень логирования
    if args.verbose:
        organizer.logger.setLevel(10)  # DEBUG

    # Запускаем в нужном режиме
    if args.watch:
        organizer.watch_mode(args.watch)
    else:
        organizer.organize_downloads()


if __name__ == "__main__":
    main()